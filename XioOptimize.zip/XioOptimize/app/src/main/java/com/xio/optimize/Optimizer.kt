package com.xio.optimize

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs

data class AppInfo(val pkg: String, val label: String)

data class Stats(
    val ramUsedPct: Int,
    val ramFreeMb: Long,
    val ramTotalMb: Long,
    val storageFreeGb: Float,
    val storageTotalGb: Float,
    val batteryPct: Int,
    val batteryTempC: Float,
    val cores: Int
)

class Optimizer(private val ctx: Context) {
    private val self = ctx.packageName
    private val prefs = ctx.getSharedPreferences("xio", Context.MODE_PRIVATE)

    fun stats(): Stats {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val total = mi.totalMem / 1048576
        val free = mi.availMem / 1048576
        val sf = StatFs(Environment.getDataDirectory().path)
        val bi = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        return Stats(
            ramUsedPct = (((total - free) * 100) / total).toInt(),
            ramFreeMb = free,
            ramTotalMb = total,
            storageFreeGb = sf.availableBytes / 1073741824f,
            storageTotalGb = sf.totalBytes / 1073741824f,
            batteryPct = lvl * 100 / scale,
            batteryTempC = temp,
            cores = Runtime.getRuntime().availableProcessors()
        )
    }

    fun launchableApps(): List<AppInfo> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { AppInfo(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .filter { it.pkg != self }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    fun games(): Set<String> = prefs.getStringSet("games", emptySet()) ?: emptySet()

    fun setGame(pkg: String, on: Boolean) {
        val s = games().toMutableSet()
        if (on) s.add(pkg) else s.remove(pkg)
        prefs.edit().putStringSet("games", s).apply()
    }

    private fun thirdParty(): List<String> =
        Shell.run("pm list packages -3").lines()
            .filter { it.startsWith("package:") }
            .map { it.removePrefix("package:").trim() }

    private fun protectedPkgs(extra: Set<String>): Set<String> {
        val pm = ctx.packageManager
        val home = pm.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
        )?.activityInfo?.packageName
        return setOfNotNull(self, home) + extra
    }

    fun boost(keep: Set<String> = emptySet()): String {
        val skip = protectedPkgs(keep)
        val targets = thirdParty().filter { it !in skip }
        targets.forEach { Shell.run("am force-stop $it") }
        Shell.run("pm trim-caches 999999999999")
        return "Stopped ${targets.size} background apps and trimmed caches"
    }

    fun trimCaches(): String {
        Shell.run("pm trim-caches 999999999999")
        return "System-wide cache trimmed"
    }

    fun gameBoost(pkg: String): String {
        Shell.run("cmd game mode performance $pkg")
        Shell.run("cmd power set-fixed-performance-mode-enabled true")
        Shell.run("cmd notification set_dnd priority")
        setAnimations(0f)
        setRefresh(120)
        val n = boost(setOf(pkg))
        ctx.packageManager.getLaunchIntentForPackage(pkg)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(it)
        }
        return "Game boost on for $pkg. $n"
    }

    fun endGameBoost(pkg: String): String {
        Shell.run("cmd game reset $pkg")
        Shell.run("cmd power set-fixed-performance-mode-enabled false")
        Shell.run("cmd notification set_dnd off")
        setAnimations(1f)
        Shell.run("settings delete system min_refresh_rate")
        Shell.run("settings delete system peak_refresh_rate")
        return "Game boost ended for $pkg"
    }

    fun setAnimations(scale: Float): String {
        Shell.run("settings put global window_animation_scale $scale")
        Shell.run("settings put global transition_animation_scale $scale")
        Shell.run("settings put global animator_duration_scale $scale")
        return "Animation scale set to $scale"
    }

    fun setRefresh(hz: Int): String {
        Shell.run("settings put system min_refresh_rate $hz")
        Shell.run("settings put system peak_refresh_rate $hz")
        return "Refresh rate locked to $hz Hz"
    }

    fun resetRefresh(): String {
        Shell.run("settings delete system min_refresh_rate")
        Shell.run("settings delete system peak_refresh_rate")
        return "Refresh rate reset"
    }

    fun batterySaver(on: Boolean): String {
        Shell.run("settings put global low_power ${if (on) 1 else 0}")
        return "Battery saver ${if (on) "on" else "off"}"
    }

    fun compileAll(): String {
        Shell.run("cmd package compile -m speed-profile -a")
        return "Apps recompiled with speed-profile"
    }

    fun restrictBackground(keep: Set<String>): String {
        val skip = protectedPkgs(keep)
        val targets = thirdParty().filter { it !in skip }
        targets.forEach { Shell.run("cmd appops set $it RUN_IN_BACKGROUND ignore") }
        return "Background activity restricted for ${targets.size} apps"
    }

    fun restoreBackground(): String {
        val targets = thirdParty()
        targets.forEach { Shell.run("cmd appops set $it RUN_IN_BACKGROUND allow") }
        return "Background activity restored for ${targets.size} apps"
    }

    fun deepIdle(): String {
        Shell.run("dumpsys deviceidle force-idle")
        return "Doze forced"
    }

    fun exitIdle(): String {
        Shell.run("dumpsys deviceidle unforce")
        return "Doze released"
    }

    fun resetAll(): String {
        setAnimations(1f)
        resetRefresh()
        batterySaver(false)
        restoreBackground()
        exitIdle()
        Shell.run("cmd notification set_dnd off")
        Shell.run("cmd power set-fixed-performance-mode-enabled false")
        return "All Xio tweaks reset to defaults"
    }
}
