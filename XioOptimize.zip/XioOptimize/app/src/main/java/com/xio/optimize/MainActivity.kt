package com.xio.optimize

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

private val Accent = Color(0xFF00E5A8)
private val Bg = Color(0xFF0B0F14)
private val Card = Color(0xFF141B24)

class MainActivity : ComponentActivity() {
    private val binderAlive = mutableStateOf(false)
    private val granted = mutableStateOf(false)

    private val onBinder = Shizuku.OnBinderReceivedListener { refresh() }
    private val onDead = Shizuku.OnBinderDeadListener { refresh() }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }

    private fun refresh() {
        val alive = Shizuku.pingBinder()
        binderAlive.value = alive
        granted.value = alive && try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
        refresh()
        val opt = Optimizer(applicationContext)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent, onPrimary = Color.Black,
                    background = Bg, surface = Card, onSurface = Color.White
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = Bg) {
                    if (granted.value) MainScreen(opt) else GateScreen(
                        alive = binderAlive.value,
                        onRequest = {
                            if (binderAlive.value) {
                                try { Shizuku.requestPermission(100) } catch (_: Exception) {}
                            } else refresh()
                        },
                        onOpenShizuku = {
                            val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                                ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))
                            startActivity(i)
                        }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
        super.onDestroy()
    }
}

@Composable
fun GateScreen(alive: Boolean, onRequest: () -> Unit, onOpenShizuku: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Xio Optimize", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Accent)
        Spacer(Modifier.height(8.dp))
        Text(
            if (alive) "Shizuku is running. Grant Xio Optimize access to continue."
            else "Shizuku is required. Install it and start it with Wireless Debugging or root, then come back.",
            color = Color(0xFFB0BAC5)
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onRequest, modifier = Modifier.fillMaxWidth()) {
            Text(if (alive) "Grant Permission" else "Check Again")
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onOpenShizuku, modifier = Modifier.fillMaxWidth()) {
            Text("Open / Get Shizuku")
        }
    }
}

@Composable
fun MainScreen(opt: Optimizer) {
    var tab by remember { mutableIntStateOf(0) }
    val log = remember { mutableStateListOf<String>() }
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }

    fun act(block: () -> String) {
        if (busy) return
        busy = true
        scope.launch {
            val r = withContext(Dispatchers.IO) { block() }
            log.add(0, r)
            busy = false
        }
    }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Card) {
                listOf("Boost", "Games", "Tools", "Info").forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(listOf("⚡", "🎮", "🛠", "📊")[i]) },
                        label = { Text(t) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> BoostTab(opt, log, busy, ::act)
                1 -> GamesTab(opt, busy, ::act)
                2 -> ToolsTab(opt, busy, ::act, log)
                else -> InfoTab(opt)
            }
        }
    }
}

@Composable
fun BoostTab(opt: Optimizer, log: List<String>, busy: Boolean, act: (() -> String) -> Unit) {
    var stats by remember { mutableStateOf(opt.stats()) }
    LaunchedEffect(log.size) { stats = opt.stats() }
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Xio Optimize", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Accent)
        Spacer(Modifier.height(24.dp))
        Box(contentAlignment = Alignment.Center) {
            CircularProgressIndicator(
                progress = { stats.ramUsedPct / 100f },
                modifier = Modifier.size(180.dp),
                strokeWidth = 12.dp,
                color = Accent,
                trackColor = Card
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${stats.ramUsedPct}%", fontSize = 40.sp, fontWeight = FontWeight.Bold)
                Text("RAM used", color = Color(0xFFB0BAC5))
            }
        }
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = { act { opt.boost(opt.games()) } },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text(if (busy) "Working..." else "BOOST NOW", fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(16.dp))
        LazyColumn(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(log) {
                Card(colors = CardDefaults.cardColors(containerColor = Card)) {
                    Text(it, Modifier.padding(12.dp).fillMaxWidth(), fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun GamesTab(opt: Optimizer, busy: Boolean, act: (() -> String) -> Unit) {
    val apps = remember { opt.launchableApps() }
    var games by remember { mutableStateOf(opt.games()) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            Spacer(Modifier.height(16.dp))
            Text("Game Booster", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Accent)
            Text("Tick your games. Tap Play to boost and launch.", color = Color(0xFFB0BAC5), fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
        }
        items(apps, key = { it.pkg }) { app ->
            val on = app.pkg in games
            Card(colors = CardDefaults.cardColors(containerColor = Card)) {
                Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = on, onCheckedChange = {
                        opt.setGame(app.pkg, it)
                        games = opt.games()
                    })
                    Text(app.label, Modifier.weight(1f), maxLines = 1)
                    if (on) {
                        TextButton(enabled = !busy, onClick = { act { opt.gameBoost(app.pkg) } }) { Text("Play") }
                        TextButton(enabled = !busy, onClick = { act { opt.endGameBoost(app.pkg) } }) { Text("End") }
                    }
                }
            }
        }
    }
}

@Composable
fun ToolsTab(opt: Optimizer, busy: Boolean, act: (() -> String) -> Unit, log: List<String>) {
    @Composable
    fun Tool(title: String, sub: String, run: () -> String) {
        Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, fontWeight = FontWeight.SemiBold)
                    Text(sub, fontSize = 12.sp, color = Color(0xFFB0BAC5))
                }
                Button(enabled = !busy, onClick = { act(run) }) { Text("Run") }
            }
        }
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Tools", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Accent)
        Tool("Clear all cache", "Trim cache of every app") { opt.trimCaches() }
        Tool("Animations off", "Instant UI on slow devices") { opt.setAnimations(0f) }
        Tool("Animations 0.5x", "Faster, still smooth") { opt.setAnimations(0.5f) }
        Tool("Animations default", "Restore 1x") { opt.setAnimations(1f) }
        Tool("Lock 60 Hz", "Save power and heat") { opt.setRefresh(60) }
        Tool("Lock 90 Hz", "Smoother display") { opt.setRefresh(90) }
        Tool("Lock 120 Hz", "Max smoothness") { opt.setRefresh(120) }
        Tool("Reset refresh rate", "Back to system control") { opt.resetRefresh() }
        Tool("Battery saver on", "Cut background load") { opt.batterySaver(true) }
        Tool("Battery saver off", "Back to normal") { opt.batterySaver(false) }
        Tool("Restrict background apps", "Block background running, except your games") { opt.restrictBackground(opt.games()) }
        Tool("Restore background apps", "Undo the restriction") { opt.restoreBackground() }
        Tool("Force Doze", "Deep sleep idle apps now") { opt.deepIdle() }
        Tool("Release Doze", "Wake normal behavior") { opt.exitIdle() }
        Tool("Recompile apps", "speed-profile, faster launches (slow)") { opt.compileAll() }
        Tool("Reset everything", "Undo all Xio tweaks") { opt.resetAll() }
        if (log.isNotEmpty()) Text(log.first(), fontSize = 13.sp, color = Accent)
    }
}

@Composable
fun InfoTab(opt: Optimizer) {
    var s by remember { mutableStateOf(opt.stats()) }
    LaunchedEffect(Unit) {
        while (true) {
            s = opt.stats()
            kotlinx.coroutines.delay(2000)
        }
    }
    @Composable
    fun Row2(k: String, v: String) {
        Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(14.dp)) {
                Text(k, Modifier.weight(1f), color = Color(0xFFB0BAC5))
                Text(v, fontWeight = FontWeight.SemiBold)
            }
        }
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Device Info", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Accent)
        Row2("RAM", "${s.ramFreeMb} MB free / ${s.ramTotalMb} MB")
        Row2("Storage", "%.1f GB free / %.1f GB".format(s.storageFreeGb, s.storageTotalGb))
        Row2("Battery", "${s.batteryPct}%  ${"%.1f".format(s.batteryTempC)}°C")
        Row2("CPU cores", "${s.cores}")
        Row2("Android", android.os.Build.VERSION.RELEASE)
        Row2("Device", "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
    }
}
