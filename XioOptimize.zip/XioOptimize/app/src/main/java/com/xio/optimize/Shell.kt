package com.xio.optimize

import rikka.shizuku.Shizuku

object Shell {
    private val method by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    fun run(cmd: String): String = try {
        val p = method.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        val err = p.errorStream.bufferedReader().readText()
        p.waitFor()
        (out + err).trim()
    } catch (e: Exception) {
        "error: ${e.cause?.message ?: e.message}"
    }
}
